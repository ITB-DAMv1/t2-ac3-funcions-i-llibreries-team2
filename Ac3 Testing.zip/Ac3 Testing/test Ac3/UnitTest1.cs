using BestSuper4Game;
namespace testCodiAC3
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        [DataRow(1500)]
        [DataRow(1000)]
        [DataRow(50000)]
        [DataRow(30547)]
        public void ChooseMaliceIn(double num)
        {
            //Arrange [1000, 50000]
            bool flag;
            //Act
            Program.ChooseMalice(ref num, out flag);
            //Assert
            Assert.IsTrue(flag);
        }
        [TestMethod]
        [DataRow(999)]
        [DataRow(50001)]
        [DataRow(-654)]
        [DataRow(999999999)]
        public void ChooseMaliceOut(double num)
        {
            //Arrange ]1000, 50000[
            bool flag;
            //Act
            Program.ChooseMalice(ref num, out flag);
            //Assert
            Assert.IsFalse(flag);
        }


        [TestMethod]
        [DataRow(10000, "ajfdsfa")]
        [DataRow(20, "aaaaaaa")]
        [DataRow(500000, "AsdsEesd")]
        [DataRow(4, "AAaaAAaa")]
        public void DistributeMaliceCorrectTwoVocals(double num, string s)
        {
            //Arrange
            double numBefore = num;
            double malice;
            //Act
            malice = Program.DistributeMalice(num, ref s);

            //Assert

            Assert.IsTrue(numBefore / 4 == malice);
        }

        [TestMethod]
        [DataRow(10000, "asdf")]
        [DataRow(20, "fffffffff")]
        [DataRow(500000, "jklmlklmn")]
        [DataRow(4, "Yillsfd")]
        public void DistributeMaliceCorrecNoTwoVocals(double num, string s)
        {
            //Arrange
            double numBefore = num;
            double malice;
            //Act
            malice = Program.DistributeMalice(num, ref s);

            //Assert

            Assert.IsTrue(numBefore * 0.95 == malice);
        }

        //tests jhon
        [TestMethod]
        [DataRow(4)]
        [DataRow(3)]
        [DataRow(1)]
        public void ChooseAvatarValidInput(int num)
        {
            //Arrange
            int validInput = num;

            // Act
            bool result = Program.ChooseAvatar(validInput);

            // Assert
            Assert.IsTrue(result);
        }
        [TestMethod]
        [DataRow(5)]
        [DataRow(0)]
        public void ChooseAvatarInvalidInput(int num)
        {
            //Arrange
            int invalidInput = num;

            //Act
            bool result = Program.ChooseAvatar(invalidInput);

            //Assert
            Assert.IsFalse(result);

        }
        //
        //tests aleix
        // Quan el nom t� m�s de 2 vocals
        [TestMethod]
        [DataRow(true, "Ababa")]
        [DataRow(true, "Ewewe")]
        [DataRow(true, "Inini")]
        public void CheckVowels_Multiple(bool expected, string name)
        {
            // Arrange
            bool vowelsValid = false;

            // Act
            BestSuper4Game.Program.Checkvowels(ref vowelsValid, ref name);

            // Assert
            Assert.AreEqual(expected, vowelsValid);
        }

        // Quan el nom t� exactament dues vocals
        [TestMethod]
        [DataRow(true, "Aba")]
        [DataRow(true, "Ewe")]
        [DataRow(true, "Ini")]
        public void CheckVowels_Two(bool expected, string name)
        {
            // Arrange
            bool vowelsValid = false;

            // Act
            BestSuper4Game.Program.Checkvowels(ref vowelsValid, ref name);

            // Assert
            Assert.AreEqual(expected, vowelsValid);
        }

        // Quan el nom t� menys de 2 vocals
        [TestMethod]
        [DataRow(false, "Ab")]
        [DataRow(false, "Ew")]
        [DataRow(false, "In")]
        public void CheckVowels_LessThanTwo(bool expected, string name)
        {
            // Arrange
            bool vowelsValid = false;

            // Act
            BestSuper4Game.Program.Checkvowels(ref vowelsValid, ref name);

            // Assert
            Assert.AreEqual(expected, vowelsValid);
        }

        // Quan el nom est� buit
        [TestMethod]
        [DataRow(false, "")]
        public void CheckVowels_Empty(bool expected, string name)
        {
            // Arrange
            bool vowelsValid = false;

            // Act
            BestSuper4Game.Program.Checkvowels(ref vowelsValid, ref name);

            // Assert
            Assert.AreEqual(expected, vowelsValid);
        }

        // Quan el nom no cont� vocals
        [TestMethod]
        [DataRow(false, "b")]
        [DataRow(false, "w")]
        [DataRow(false, "n")]
        public void CheckVowels_Zero(bool expected, string name)
        {
            // Arrange
            bool vowelsValid = false;

            // Act
            BestSuper4Game.Program.Checkvowels(ref vowelsValid, ref name);

            // Assert
            Assert.AreEqual(expected, vowelsValid);
        }
        //
    }
}